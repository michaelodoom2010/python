# A program to calculate tuition costs based on course enrollment
# Date: Feb. 26, 2025
# CSC-121 m3Pro - Purchases
# Michael Odoom

# Lists containing course names and corresponding tuition costs
courses = [
    "MAT 035 (Concepts of Algebra)", "BAS 120 Intro to Analytics",
    "CSC 101 (Intro to Computer Science)", "ENG 101 (English Composition)",
    "HIS 205 (World History)"
]
tuition = [460, 500, 550, 400, 450]

stu_names = ["Alice", "Bob", "Charlie", "David"]

def course_display():
    """Displays courses and their tuition in tabular format."""
    print("\nCourses and Tuition:")
    print("{:<40} {:<10}".format("Course Name", "Tuition ($)"))
    print("-" * 50)
    for i in range(len(courses)):
        print("{:<40} ${:<10}".format(courses[i], tuition[i]))  # Added $ sign in formatting

def student_registration():
    """Registers students for courses and calculates tuition."""
    total_tuition = {}
    for student in stu_names:
        print(f"\nRegistering courses for {student}:")
        total = 0
        for i in range(len(courses)):
            choice = input(f"Is {student} registered for {courses[i]}? (y/n): ")
            if choice.lower() == 'y':
                total += tuition[i]
        total_tuition[student] = total
    
    print("\nStudent Tuition Summary:")
    print("{:<20} {:<10}".format("Student Name", "Tuition ($)"))
    print("-" * 30)
    for student, cost in total_tuition.items():
        print("{:<20} ${:<10}".format(student, cost))  # Added $ sign in formatting

def individual_student_tuition():
    """Displays tuition for an individual student."""
    print("\nSelect a student:")
    for i, student in enumerate(stu_names, 1):
        print(f"{i}. {student}")
    
    try:
        student_choice = int(input("Enter student number: ")) - 1
        if 0 <= student_choice < len(stu_names):
            student = stu_names[student_choice]
            total = 0
            for i in range(len(courses)):
                registered = input(f"Is {student} registered for {courses[i]}? (y/n): ")
                if registered.lower() == 'y':
                    total += tuition[i]
            print(f"\n{student}'s total tuition cost: ${total}")
        else:
            print("Invalid selection. Please enter a valid number.")
    except ValueError:
        print("Invalid input. Please enter a number.")

def main():
    while True:
        print("\nOptions:")
        print("1. Register all students")
        print("2. Register a single student")
        print("3. Exit")
        option = input("Enter your choice: ")
        if option == "1":
            student_registration()
        elif option == "2":
            individual_student_tuition()
        elif option == "3":
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    course_display()
    main()