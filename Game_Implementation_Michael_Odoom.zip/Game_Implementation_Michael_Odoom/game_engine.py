from game_classes import *
import random

class GameEngine:
    def __init__(self):
        self.player = None
        self.current_room = None
        self.game_over = False
        self.victory = False
        self.rooms = []
    
    def initialize_game(self):
        # Create player
        player_name = input("Enter your character's name: ")
        self.player = Player(player_name)
        
        # Create rooms
        self._create_world()
        
        # Place player in starting room
        self.current_room = self.rooms[0]
        self.player.current_room = self.current_room
    
    def _create_world(self):
        # Create rooms
        room_descriptions = [
            "a dimly lit cavern with damp walls",
            "a large hall with strange carvings",
            "a narrow tunnel with glowing moss",
            "a circular chamber with a high ceiling",
            "a room filled with broken furniture",
            "a cave with a small underground stream",
            "a chamber with ancient murals on the walls",
            "a room with a strange altar in the center"
        ]
        
        self.rooms = [Room(desc) for desc in room_descriptions]
        
        # Connect rooms randomly
        directions = [d.value for d in Direction]
        for i, room in enumerate(self.rooms):
            for _ in range(random.randint(1, 3)):
                dir_choice = random.choice(directions)
                target_idx = random.randint(0, len(self.rooms)-1)
                if target_idx != i:
                    room.add_connection(dir_choice, self.rooms[target_idx])
        
        # Add enemies to some rooms
        enemy_types = [
            ("Goblin", 30, 8, 50),
            ("Orc", 50, 12, 80),
            ("Skeleton", 25, 10, 40),
            ("Spider", 20, 6, 30),
            ("Troll", 70, 15, 120)
        ]
        
        for room in random.sample(self.rooms, len(self.rooms)//2):
            name, health, attack, exp = random.choice(enemy_types)
            room.add_enemy(Enemy(name, health, attack, exp))
        
        # Add items to some rooms
        items = [
            ("Health Potion", "Restores 30 HP", "heal", 30),
            ("Attack Potion", "Boosts attack by 5", "attack_boost", 5),
            ("Great Health Potion", "Restores 60 HP", "heal", 60),
            ("Mighty Attack Potion", "Boosts attack by 10", "attack_boost", 10)
        ]
        
        for room in random.sample(self.rooms, len(self.rooms)//3):
            name, desc, effect, value = random.choice(items)
            room.add_item(Item(name, desc, effect, value))
    
    def display_status(self):
        print(f"\n{self.player.name} - Level {self.player.level}")
        print(f"HP: {self.player.health}/{self.player.max_health}")
        print(f"Attack: {self.player.attack_power}")
        print(f"XP: {self.player.experience}/{self.player.level * 100}")
    
    def display_room(self):
        print(f"\nYou are in {self.current_room.description}")
        
        if self.current_room.item:
            print(f"You see a {self.current_room.item.name} here!")
        
        if self.current_room.enemy and self.current_room.enemy.is_alive():
            print(f"A wild {self.current_room.enemy.name} appears! (HP: {self.current_room.enemy.health})")
        
        print("\nAvailable directions:")
        for direction in self.current_room.get_available_directions():
            print(f"- {direction.capitalize()}")
    
    def combat_turn(self):
        enemy = self.current_room.enemy
        
        # Player attacks first
        print(self.player.attack(enemy))
        if not enemy.is_alive():
            print(f"You defeated the {enemy.name}!")
            self.player.add_experience(enemy.experience_reward)
            self.current_room.enemy = None
            return True
        
        # Enemy attacks back
        print(enemy.attack(self.player))
        if not self.player.is_alive():
            print("You have been defeated!")
            self.game_over = True
            return False
        
        return None  # Combat continues
    
    def move_player(self, direction):
        if direction in self.current_room.connections:
            self.current_room = self.current_room.connections[direction]
            self.player.current_room = self.current_room
            print(f"You move {direction}.")
            return True
        print("You can't go that way.")
        return False
    
    def pickup_item(self):
        if self.current_room.item:
            item = self.current_room.item
            self.player.inventory.append(item)
            self.current_room.item = None
            print(f"You picked up the {item.name}!")
            return True
        print("There's nothing to pick up here.")
        return False
    
    def show_inventory(self):
        if not self.player.inventory:
            print("Your inventory is empty.")
            return
        
        print("\nInventory:")
        for i, item in enumerate(self.player.inventory):
            print(f"{i+1}. {item.name}: {item.description}")
    
    def main_loop(self):
        print("\n=== DUNGEON ADVENTURE ===")
        self.initialize_game()
        
        while not self.game_over and not self.victory:
            self.display_status()
            self.display_room()
            
            if self.current_room.enemy and self.current_room.enemy.is_alive():
                print("\nCOMBAT MENU:")
                print("1. Attack")
                print("2. Use item")
                print("3. Try to flee")
                
                choice = input("Choose an action: ")
                
                if choice == "1":
                    result = self.combat_turn()
                    if result is not None:
                        if result:
                            print("You won the battle!")
                        else:
                            break
                elif choice == "2":
                    self.show_inventory()
                    if self.player.inventory:
                        try:
                            item_choice = int(input("Select item to use (number): ")) - 1
                            print(self.player.use_item(item_choice))
                        except (ValueError, IndexError):
                            print("Invalid selection.")
                elif choice == "3":
                    if random.random() < 0.5:  # 50% chance to flee
                        print("You successfully fled!")
                        self.move_player(random.choice(list(self.current_room.connections.keys())))
                    else:
                        print("You failed to flee!")
                        print(self.current_room.enemy.attack(self.player))
                        if not self.player.is_alive():
                            self.game_over = True
                else:
                    print("Invalid choice.")
            else:
                print("\nMAIN MENU:")
                print("1. Move")
                print("2. Pick up item")
                print("3. Check inventory")
                print("4. Quit game")
                
                choice = input("Choose an action: ")
                
                if choice == "1":
                    direction = input("Enter direction (north/south/east/west): ").lower()
                    if direction in [d.value for d in Direction]:
                        self.move_player(direction)
                    else:
                        print("Invalid direction.")
                elif choice == "2":
                    self.pickup_item()
                elif choice == "3":
                    self.show_inventory()
                elif choice == "4":
                    self.game_over = True
                else:
                    print("Invalid choice.")
        
        if self.game_over:
            print("\nGAME OVER")
        else:
            print("\nVICTORY!")

if __name__ == "__main__":
    game = GameEngine()
    game.main_loop()