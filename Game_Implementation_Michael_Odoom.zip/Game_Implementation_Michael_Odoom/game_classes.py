import random
from enum import Enum

class Direction(Enum):
    NORTH = "north"
    SOUTH = "south"
    EAST = "east"
    WEST = "west"

class Item:
    def __init__(self, name, description, effect_type, effect_value):
        self.name = name
        self.description = description
        self.effect_type = effect_type  # 'heal' or 'attack_boost'
        self.effect_value = effect_value
    
    def use(self, target):
        if self.effect_type == 'heal':
            target.health = min(target.max_health, target.health + self.effect_value)
            return f"{target.name} healed for {self.effect_value} HP!"
        elif self.effect_type == 'attack_boost':
            target.attack_power += self.effect_value
            return f"{target.name}'s attack increased by {self.effect_value}!"
        return "Item had no effect."

class Character:
    def __init__(self, name, health, attack_power):
        self.name = name
        self.max_health = health
        self.health = health
        self.attack_power = attack_power
    
    def attack(self, target):
        damage = random.randint(self.attack_power // 2, self.attack_power)
        target.take_damage(damage)
        return f"{self.name} attacks {target.name} for {damage} damage!"
    
    def take_damage(self, amount):
        self.health -= amount
        if self.health < 0:
            self.health = 0
    
    def is_alive(self):
        return self.health > 0

class Player(Character):
    def __init__(self, name):
        super().__init__(name, 100, 10)
        self.inventory = []
        self.experience = 0
        self.level = 1
        self.current_room = None
    
    def add_experience(self, amount):
        self.experience += amount
        exp_needed = self.level * 100
        if self.experience >= exp_needed:
            self.level_up()
    
    def level_up(self):
        self.level += 1
        self.max_health += 20
        self.health = self.max_health
        self.attack_power += 5
        return f"Level up! You are now level {self.level}!"
    
    def use_item(self, item_index):
        if 0 <= item_index < len(self.inventory):
            item = self.inventory.pop(item_index)
            return item.use(self)
        return "Invalid item selection."

class Enemy(Character):
    def __init__(self, name, health, attack_power, experience_reward):
        super().__init__(name, health, attack_power)
        self.experience_reward = experience_reward

class Room:
    def __init__(self, description):
        self.description = description
        self.connections = {}
        self.enemy = None
        self.item = None
    
    def add_connection(self, direction, room):
        self.connections[direction] = room
    
    def add_enemy(self, enemy):
        self.enemy = enemy
    
    def add_item(self, item):
        self.item = item
    
    def get_available_directions(self):
        return list(self.connections.keys())