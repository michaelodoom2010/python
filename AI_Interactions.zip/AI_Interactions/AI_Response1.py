class Character:
    def __init__(self, name, health, attack):
        self.name = name
        self.health = health
        self.attack = attack
    
    def take_damage(self, damage):
        self.health -= damage
        return self.health > 0

class Player(Character):
    def __init__(self, name):
        super().__init__(name, 100, 10)
        self.inventory = []
        self.level = 1
        self.exp = 0

class Enemy(Character):
    def __init__(self, name, health, attack, exp_reward):
        super().__init__(name, health, attack)
        self.exp_reward = exp_reward

class Item:
    def __init__(self, name, effect):
        self.name = name
        self.effect = effect

class Room:
    def __init__(self, description):
        self.description = description
        self.connections = {}
        self.enemy = None
        self.item = None