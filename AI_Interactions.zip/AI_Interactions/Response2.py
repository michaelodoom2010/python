def combat_round(player, enemy):
    # Player attacks first
    player_damage = random.randint(player.attack // 2, player.attack)
    enemy.take_damage(player_damage)
    print(f"You hit {enemy.name} for {player_damage} damage!")
    
    if enemy.health <= 0:
        print(f"You defeated {enemy.name}!")
        player.exp += enemy.exp_reward
        return True
    
    # Enemy attacks back
    enemy_damage = random.randint(enemy.attack // 2, enemy.attack)
    player.take_damage(enemy_damage)
    print(f"{enemy.name} hits you for {enemy_damage} damage!")
    
    if player.health <= 0:
        print("You have been defeated!")
        return False
    
    return None  # Combat continues