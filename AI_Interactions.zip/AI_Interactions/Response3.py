def check_level_up(player):
    exp_needed = player.level * 100
    if player.exp >= exp_needed:
        player.level += 1
        player.health += 20
        player.attack += 5
        print(f"Level up! You are now level {player.level}!")
        return True
    return False

# After defeating an enemy:
player.exp += enemy.exp_reward
check_level_up(player)